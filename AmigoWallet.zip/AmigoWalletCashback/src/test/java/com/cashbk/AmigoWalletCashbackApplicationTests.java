package com.cashbk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmigoWalletCashbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
