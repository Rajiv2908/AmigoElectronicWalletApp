package com.cashbk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmigoWalletCashbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmigoWalletCashbackApplication.class, args);
	}
}
