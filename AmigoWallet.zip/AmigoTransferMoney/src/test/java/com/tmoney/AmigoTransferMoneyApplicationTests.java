package com.tmoney;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmigoTransferMoneyApplicationTests {

	@Test
	void contextLoads() {
	}

}
