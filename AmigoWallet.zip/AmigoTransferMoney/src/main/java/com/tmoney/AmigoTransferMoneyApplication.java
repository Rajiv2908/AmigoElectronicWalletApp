package com.tmoney;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmigoTransferMoneyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmigoTransferMoneyApplication.class, args);
	}

}
