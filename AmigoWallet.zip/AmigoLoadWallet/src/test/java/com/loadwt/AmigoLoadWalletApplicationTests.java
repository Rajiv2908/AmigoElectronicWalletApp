package com.loadwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmigoLoadWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
