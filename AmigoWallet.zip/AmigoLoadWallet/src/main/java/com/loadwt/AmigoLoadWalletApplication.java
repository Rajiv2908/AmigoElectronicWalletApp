package com.loadwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmigoLoadWalletApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmigoLoadWalletApplication.class, args);
	}

}
