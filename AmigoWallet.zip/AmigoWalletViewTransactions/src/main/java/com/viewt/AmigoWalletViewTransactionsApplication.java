package com.viewt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmigoWalletViewTransactionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmigoWalletViewTransactionsApplication.class, args);
	}
}
