package com.amigo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmigoElectronicWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
