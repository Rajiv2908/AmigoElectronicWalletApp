package com.offers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmigoEWalletOffersApplicationTests {

	@Test
	void contextLoads() {
	}

}
