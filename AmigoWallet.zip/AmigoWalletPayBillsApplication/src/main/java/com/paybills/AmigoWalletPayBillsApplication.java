package com.paybills;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmigoWalletPayBillsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmigoWalletPayBillsApplication.class, args);
	}
}
